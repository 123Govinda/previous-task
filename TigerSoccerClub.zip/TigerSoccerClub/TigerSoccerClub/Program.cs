﻿using System;

namespace TigerSoccerClub
{
    class Program
    {
        private static int initalamt_kids = 150;
        private static int initalamt_adult = 230;
        private static int jerseyamt = 100;

        public Program(int players, string name, string registration, string jersey, double price)
        {
            Players = players;
            Name = name;
            Registration = registration;
            Jersey = jersey;
            Price = price;
        }

        public int Players { get; set; }
        public string Name { get; set; }
        public string Registration { get; set; }
        public string Jersey { get; set; }
        public double Price { get; set; }

        static void Main(string[] args)
        {
            Console.Write("Enter the number of players per registrations: ");
            int totalPlayers = Convert.ToInt32(Console.ReadLine());

            if (totalPlayers > 4 || totalPlayers < 1)
            {
                Console.WriteLine("Invalid number, Please enter the registration number between 1 to 4");
            }
            else
            {
                Program[] playersArray = new Program[totalPlayers];

                for (int i = 0; i < totalPlayers; i++)
                {
                    GetPlayerDetails(out string name, out string registration, out string jersey);

                    double total = CalculateTotalPrice(registration, jersey);
                    PrintRegistrationDetails(name, registration, jersey, total);

                    playersArray[i] = new Program(totalPlayers, name, registration, jersey, total);
                }

                PrintSummary(playersArray);
            }
        }

        static void GetPlayerDetails(out string name, out string registration, out string jersey)
        {
            Console.Write("Enter name: ");
            name = Console.ReadLine();

            Console.Write("Registration type: ");
            registration = Console.ReadLine();

            Console.Write("Enter Yes/No to indicate whether you want a jersey: ");
            jersey = Console.ReadLine();
        }

        static double CalculateTotalPrice(string registration, string jersey)
        {
            double basePrice = (registration == "Kids") ? initalamt_kids : initalamt_adult;
            double total = jersey.ToLower() == "yes" ? basePrice + jerseyamt : basePrice;
            double discount = (total * 5) / 100;
            return total - discount;
        }

        static void PrintRegistrationDetails(string name, string registration, string jersey, double total)
        {
            Console.WriteLine($"Total price from {name} is: {total}\n");
        }

        static void PrintSummary(Program[] playersArray)
        {
            Console.WriteLine("Summary of Registrations");
            Console.WriteLine("******************************************************************************************************");
            Console.WriteLine("Name\tType\tJersey\tTotal");
            Console.WriteLine();

            foreach (var player in playersArray)
            {
                Console.WriteLine($"{player.Name}\t{player.Registration}\t{player.Jersey}\t{player.Price}");
            }
        }
    }
}
